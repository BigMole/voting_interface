var mongoose = require('mongoose');
var config   = require('../config');
var logger = require('../common/logger');


mongoose.connect(config.db, {
  socketTimeoutMS: 0,
  keepAlive: true,
  reconnectTries: 30,
  poolSize: 20,
  useNewUrlParser: false
}, function (err) {
  if (err) {
    logger.error('connect to %s error: ', config.db, err.message);
    process.exit(1);
  }
});

// models
require('./user');
require('./candidates');

exports.User         = mongoose.model('User');
exports.Candidates         = mongoose.model('Candidates');

