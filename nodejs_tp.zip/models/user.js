var mongoose  = require('mongoose');
var BaseModel = require("./base_model");
var Schema    = mongoose.Schema;
var utility   = require('utility');
var _ = require('lodash');

var UserSchema = new Schema({
  
  user_account :{type: String},// "用户账号",  //唯一  矿工
  user_pass : {type: String},//"用户密码",
  user_mail : {type: String},//"用户绑定邮箱",
  user_lastlog:{type: Date},//"用户最近一次登陆时间",
  create_at: { type: Date, default: Date.now },
  update_at: { type: Date, default: Date.now }, 
  votes_info:{type:String}//  1|2|3  表示投票给了 1 2 3 号

});

UserSchema.plugin(BaseModel);

UserSchema.index({user_account: 1}, {unique: true});
UserSchema.index({user_mail: 1}, {unique: true});

//记录更新时间
UserSchema.pre('save', function(next){
  var now = new Date();
  this.update_at = now;
  next();
});

mongoose.model('User', UserSchema);
