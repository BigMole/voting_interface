var mongoose  = require('mongoose');
var BaseModel = require("./base_model");
var Schema    = mongoose.Schema;

var CandidatesSchema = new Schema({
  
  candidate_id :{type: String},      // ID
  candidate_name : {type: String},   //候选人名字
  tickets : {type: Number,default: 0},          //投票数
  create_at: { type: Date, default: Date.now },
  update_at: { type: Date, default: Date.now }

});

CandidatesSchema.plugin(BaseModel);
CandidatesSchema.index( {candidate_id : 1}, {unique: true} );


//记录更新时间
CandidatesSchema.pre('save', function(next){

  var now = new Date();
  this.update_at = now;
  next();
});

mongoose.model('Candidates', CandidatesSchema);
