let config= require('../config.js') ;
let jwt= require('../common/jwt.js') ;
let express = require('express');

exports.auth=function(req,res,next){

  if((req.originalUrl).indexOf('register')==-1&&(req.originalUrl).indexOf('login')==-1){
  var token = req.body.token || req.query.token || req.headers['x-access-token'];
  if (token) {

    jwt.checkToken(token,function(err, decoded) {      
      if (err) {
          return res.json({ reMsg: '无效的token.' });   
          
      } else {
          //验证通过
          req.decoded = decoded;  
          next(); //继续下一步路由
        
      }       
      });;   
      
    } else {
      // 没有拿到token 返回错误 
      return res.status(403).send({          
          reMsg: '请使用token' 
      });

      }
   }else{
      next(); //继续下一步路由
   }


}