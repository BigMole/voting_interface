var express = require('express');
var moment = require('moment');
var path = require('path');
var config = require('../config');
var jwt= require('jsonwebtoken');



var nowtime=moment().valueOf();
var expires = moment().add( 2,'hours').valueOf();


exports.getToken=function(user){
   return jwt.sign({
        iss: "Dilili",
        iat: nowtime,
        user:user
    }, config.jsontoken_secret, {
        expiresIn:  60*60*24 //秒到期时间
    });
    


};
exports.checkToken=function(token,callback){

    // 解码 token (验证 secret 和检查有效期（exp）)
    jwt.verify(token, config.jsontoken_secret, callback);
    
};


