var bcrypt = require('bcryptjs');
var moment = require('moment');
var config = require('../config');

moment.locale('zh-cn'); // 使用中文

// 格式化时间
exports.formatDate = function (date, friendly) {
  date = moment(date);

  if (friendly) {
    return date.fromNow();
  } else {
    return date.format('YYYY-MM-DD HH:mm');
  }

};

exports.validateId = function (str) {
  return (/^[a-zA-Z0-9\-_]+$/i).test(str);
};

exports.bhash = function (str, callback) {
  bcrypt.hash(str, 10, callback);
};

exports.bcompare = function (str, hash, callback) {
  bcrypt.compare(str, hash, callback);
};


function fillEmpty(str, num) {
  str=str+'';
  if(str.length>=num)return str;
  for(var i=0;i<=num-str.length;i++){
	  str+='0';
  }
  return str;
};
exports.fillEmpty = fillEmpty;

function strtonum (str){
  let sum=0;
  str=new Buffer(str).toString('hex');
	for(var i=0;i<str.length;i++)
	{

		sum+=parseInt(str[i],16);
		
	}
	return sum;
}
exports.strtonum = strtonum;

function valificationCode(str){
//为了发送邮件验证码，可以进行邮件有效性确认
//获取今天星期几，以及几天是几月几号。 对应的数字 与配置的密码进行 混合运算 	
	var day=moment().days();
	var userNum=strtonum(str);
	var valificationCodeSecret=strtonum(config.valificationCodeSecret);
	var sercretNum=(++day)*valificationCodeSecret;	
	var returnCode=fillEmpty ( (userNum+sercretNum)%10000,4);
	
	return returnCode;
	
}

exports.valificationCode=valificationCode;

exports.valificationCodeCheck=function(str,user_mail,callback){
    
    return callback( str==valificationCode(user_mail) );
    
  }
  
 