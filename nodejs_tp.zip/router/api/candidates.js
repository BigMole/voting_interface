var validator      = require('validator');
var eventproxy     = require('eventproxy');
var moment     = require('moment');
var config         = require('../../config');
var tools         = require('../../common/tools');
var Candidates           = require('../../proxy').Candidates;
var User           = require('../../proxy').User;

//初始化缓存
global.cacheCandidates={
    info:'',
    expireTime:''
};
/*
新增候选人

*/
exports.addCandidates=function(req,res,next){
    
    
    
    let admin=req.decoded.user.admin;//获取解密信息
    if(!admin)return res.status(401).json({reMsg : '请您先登陆'});
    if(global.voting_switch==1)return res.status(401).json({reMsg : '投票系统已开启无法进行候选人操作，请先关闭系统再进行操作'});
    
    if(!req.query.candidate_name||!req.query.candidate_id){
        res.status(412);   
        res.json({reMsg : '信息不完整'});
        return;
      }
    
    
    var candidate_name     = validator.trim(req.query.candidate_name).toLowerCase();
    var candidate_id     = validator.trim(req.query.candidate_id).toLowerCase();
    
    var ep = new eventproxy();

  
   ep.on('prop_err', function (msg) {
    res.status(412);   
    res.json({reMsg : msg});
  
    });
    
    ep.on('prop_success', function (msg) {
      res.status(200);   
      
      res.json({reMsg : msg});
  
    });

    if (!tools.validateId(candidate_id)) {
        return ep.emit('prop_err', '候选编号不合法。');
      }

      Candidates.getCandidateById(candidate_id,function(err,doc){
        if (err) {
            return next(err);
            }
            if (doc.length > 0) {
            ep.emit('prop_err', '候选编号已经被使用');
            return ;
            }else{
                //入库操作
                Candidates.addCandidates({'candidate_name':candidate_name,'candidate_id':candidate_id},function(err,doc){
                    if(!err){
                        ep.emit('prop_success', '新增成功');return;
                    
                    }else{
                        ep.emit('prop_err', '入库失败'); return;
                    }       
                });       
            }

         

        
        });
   
   
	};
	

/*
*查询候选人
*使用全局方式进行一个缓存数据每30秒有效期之后访问，再进行数据库访问处理
*/
exports.getCandidates=function(req,res){
    //获取身份信息
    let admin=req.decoded.user.admin;//获取解密信息
    if(!admin)return res.status(401).json({reMsg : '请您先登陆'});
    
    
    var ep = new eventproxy();
    
     ep.on('prop_err', function (msg) {
      res.status(412);   
      res.json({reMsg : msg,infos:infos});
    
      });
      
      ep.on('prop_success', function (msg) {
        res.status(200);           
        res.json({reMsg : msg});
    
      });
        

      if(!global.cacheCandidates.info||global.cacheCandidates.expireTime<=moment.now()){
        
        //过了有效期那么进入数据库查询返回候选人信息，并更新缓存
        Candidates.getCandidates(ep.done(function(doc,err){
            ep.emit('prop_success', {msg:'查询成功',infos:doc});
            global.cacheCandidates.info=doc;
            global.cacheCandidates.expireTime=moment.now()+30000;
            return;


        }));

      }else{
          //缓存未到过期时间那么直接使用缓存数据
          ep.emit('prop_success', {msg:'查询成功',infos:global.cacheCandidates.info});

      }
      
     
      };


/*
修改候选人
*/
exports.modifyCandidates=function(req,res){
    //获取身份信息
    let admin=req.decoded.user.admin;//获取解密信息
    if(!admin)return res.status(401).json({reMsg : '请您先登陆'});
    if(global.voting_switch==1)return res.status(401).json({reMsg : '投票系统已开启无法进行候选人操作，请先关闭系统再进行操作'});
   
    if(!req.query.candidate_name||!req.query.candidate_id){
        res.status(412);   
        res.json({reMsg : '信息不完整'});
        return;
      }
    
   
   
    var candidate_name     = validator.trim(req.query.candidate_name).toLowerCase();
    var candidate_id     = validator.trim(req.query.candidate_id).toLowerCase(); 
    
    var ep = new eventproxy();

    
     ep.on('prop_err', function (msg) {
      res.status(412);   
      res.json({reMsg : msg});
    
      });
      
      ep.on('prop_success', function (msg) {
        res.status(200);           
        res.json({reMsg : msg});
    
      });
       
      if (candidate_name=='') {
        return ep.emit('prop_err', '候选人姓名不能为空。');
      }

      
      //修改候选人信息
       Candidates.modifyCandidates(candidate_id,candidate_name,ep.done(function(doc,err){
        if(doc){
            ep.emit('prop_success', '修改成功');
            return;
        }else{
            ep.emit('prop_err', '所给候选人ID不存在，修改失败'); return;
        }
  
      }));
     
      };

/*
删除候选人
*/
exports.deleteCandidates=function(req,res){
  
    //获取身份信息
    let admin=req.decoded.user.admin;//获取解密信息
    if(!admin)return res.status(401).json({reMsg : '请您先登陆'});
    if(global.voting_switch==1)return res.status(401).json({reMsg : '投票系统已开启无法进行候选人操作，请先关闭系统再进行操作'});
   
    if(!req.query.candidate_id){
        res.status(412);   
        res.json({reMsg : '信息不完整'});
        return;
      }
    
    var candidate_id     = validator.trim(req.query.candidate_id).toLowerCase(); 
    
    var ep = new eventproxy();
    
     ep.on('prop_err', function (msg) {
      res.status(412);   
      res.json({reMsg : msg});
    
      });
      
      ep.on('prop_success', function (msg) {
        res.status(200);           
        res.json({reMsg : msg});
    
      });
       
      if (candidate_id=='') {
        return ep.emit('prop_err', '候选编号不能为空。');
      }

      
      //删除候选人信息
       Candidates.deleteCandidates(candidate_id,function(err,doc){
        if(doc){
            ep.emit('prop_success', '删除成功');
            return;
        }else{
            ep.emit('prop_err', '无效候选人ID，删除失败'); return;
        }
  
      });
     
      };

