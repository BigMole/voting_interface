var validator      = require('validator');
var eventproxy     = require('eventproxy');
var config         = require('../../config');
var User           = require('../../proxy').User;
var mail           = require('../../common/mail');
var tools          = require('../../common/tools');
var jwt           = require('../../common/jwt.js');


/*验证码获取--
  对于邮箱有效性的确认的验证码并未保存在服务器或客户端,而是采用了与日期和配置密码
  以及用户邮箱地址相结合的加密方式。通过验证客户输入的验证码是否符合来确定客户的
  邮箱有效。
*/
exports.verficationCode=function(req,res){
  
  if(!req.query.user_mail){
    res.status(412);   
    res.json({reMsg : '信息不完整'});
    return;
  }
 // console.log(req);
  var user_mail     = validator.trim(req.query.user_mail).toLowerCase();

	var ep = new eventproxy();

  
   ep.on('prop_err', function (msg) {
    res.status(412);   
    res.json({reMsg : msg});
  
    });
    
    ep.on('prop_success', function (msg) {
      res.status(200);   
      
      res.json({reMsg : msg});
  
    });

    if (!validator.isEmail(user_mail)) {
      return ep.emit('prop_err', '邮箱不合法。');
    }
    //生成验证码
    var valificationCode= tools.valificationCode(user_mail);
    
    // 发送邮件验证码   测试通过，能收到验证码邮件  待正式使用开放
    mail.sendValiCodeMail(user_mail,"投票人", valificationCode);
    return ep.emit('prop_success', '验证码已发送');
	};
	



/**
 * 注册操作
 *
 * @param {HttpRequest} req
 * @param {HttpResponse} res
 * @param {Function} next
 */
exports.signup = function (req, res, next) {

  if(!req.query.user_account||!req.query.user_mail||!req.query.user_pass||!req.query.vali_code){
    res.status(412);   
    res.json({reMsg : '信息不完整'});
    return;
  }
  var user_account  = validator.trim(req.query.user_account).toLowerCase();
  var user_mail     = validator.trim(req.query.user_mail).toLowerCase();
  var user_pass     = validator.trim(req.query.user_pass);
  var valiCode      = validator.trim(req.query.vali_code);
 
	var ep = new eventproxy();

	ep.on('prop_err', function (msg) {
	res.status(412);   
	res.json({reMsg : msg});

	});
	
	ep.on('prop_success', function (msg) {
		res.status(200);   
		
		res.json({reMsg : msg.msg,token:msg.token});

	  });

  // 验证信息的正确性
  
    //检查数据是否有空
    if ([user_account, user_pass, user_mail ].some(function (item) { return item === ''; })) {
      ep.emit('prop_err', '信息不完整。');
      return;
    }
    
    if (!tools.validateId(user_account)) {
      ep.emit('prop_err', '用户名不合法。');
      return;
    }
  
    if (!validator.isEmail(user_mail)) {
      return ep.emit('prop_err', '邮箱不合法。');
    }

    tools.valificationCodeCheck(valiCode,user_mail,function(same){
      if(!same)  {ep.emit('prop_err', '验证码不正确。');return}

      User.getUsersByQuery({'$or': [
        {'user_account': user_account},
        {'user_mail': user_mail}
      ]}, {}, function (err, users) {
        if (err) {
          return next(err);
        }
        if (users.length > 0) {
          ep.emit('prop_err', '用户名或邮箱已被使用。');
          return;
        }else{
          var user_info={user_account:user_account,user_mail:user_mail};
          var token=jwt.getToken(user_info);
          
         
          //对用户密码加密
          tools.bhash(user_pass, ep.done(function (passhash) {
      
            User.newAndSave(user_account, passhash, user_mail,  function (err) {
              if (err) {
                return next(err);
              }
              
              return ep.emit('prop_success', {msg:"注册成功",token:token});
             
            });
    
    
          }));
    
    
    
        }
    
        
      });
    
    
    
    
    });
  
  

  // END 验证信息的正确性


  
};
