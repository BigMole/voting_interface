var validator      = require('validator');
var eventproxy     = require('eventproxy');
var config         = require('../../config');
var User           = require('../../proxy').User;
var jwt           = require('../../common/jwt.js');

/**
 * 工作人员登陆.
 *
 * @param {HttpRequest} req
 * @param {HttpResponse} res
 * @param {Function} next
 */
exports.login = function (req, res, next) {

    if(!req.query.user_account||!req.query.user_pass){
        res.status(412);   
        res.json({reMsg : '信息不完整'});
        return;
      }
      
    var user_account = validator.trim(req.query.user_account).toLowerCase();
    var user_pass      = validator.trim(req.query.user_pass);
  
    var ep        = new eventproxy();
    ep.fail(next);

    ep.on('prop_err', function (msg) {
        res.status(412);   
        res.json({reMsg : msg});
      
        });
        
        ep.on('prop_success', function (msg) {
          res.status(200);   
          
          res.json({reMsg : msg.msg,token:msg.token});
      
        });

    if (!user_account || !user_pass) {
      res.status(422);
      
      return ep.emit('prop_err','信息不完整。');
    }

    //工作人员登录账号密码预制
    var admin = config.admin;
    
    if(user_account!=admin.user_account||user_pass!=admin.user_pass){
        return ep.emit('prop_err','登录账号或密码错误。');

    }else{
        var user_info={user_account:user_account,admin:1};
        var token=jwt.getToken(user_info);
        return ep.emit('prop_success', {msg:"登录成功",token:token});    
    }
    


  };
  


  //普通用户登录----经确认无需登录功能