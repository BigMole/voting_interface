var validator      = require('validator');
var eventproxy     = require('eventproxy');
var logger     = require('../../common/logger');
var fs     = require('fs');
var config         = require('../../config');
var User           = require('../../proxy').User;
var Candidates           = require('../../proxy').Candidates;

//以文本的读取来控制投票系统的开始，可以在现场出现工作人员不小心操作错误之后无需进入数据库进行修改。
//写入文件操作
function writeBackSwitch(str){

    fs.writeFile('switchs.txt',str,{},function(err){
             if(err){       
                 logger.error("文件写入失败");              
             }else{
                //logger.error("文件写入成功");  
        
             }
        
        }) 
}
exports.writeBackSwitch=writeBackSwitch;

//投票开启操作
exports.voteBegin=function(req,res){

    //工作人员的登录之后的操作
    let voting_switch=fs.readFileSync('switchs.txt').toString();
    let admin=req.decoded.user.admin;//获取解密信息
    if(!admin)return res.status(401).json({reMsg : '请您先登陆'});
    let ep        = new eventproxy();


    ep.on('prop_err', function (msg) {
        res.status(412);   
        res.json({reMsg : msg});
      
        });
        
    ep.on('prop_success', function (msg) {
        res.status(200);   
        
        res.json({reMsg : msg});
    
    });

    if(voting_switch==1&& global.voting_switch==1){
        ep.emit('prop_err', '投票系统无法重复开始');
       
    }else{
        voting_switch=1;
        global.voting_switch=1;
        ep.emit('prop_success', '投票系统开启成功');
        writeBackSwitch(voting_switch);
    }
         return; 

}     

//投票关闭操作
exports.voteEnd=function(req,res){
    //工作人员的登录之后的操作
    let voting_switch=fs.readFileSync('switchs.txt').toString();
    let admin=req.decoded.user.admin;//获取解密信息
    if(!admin)return res.status(401).json({reMsg : '请您先登陆'});

    let ep        = new eventproxy();

    ep.on('prop_err', function (msg) {
        res.status(412);   
        res.json({reMsg : msg});
      
        });
    
    ep.on('prop_success', function (msg) {
        res.status(200);   
        
        res.json({reMsg : msg});
    
    });

     //工作人员的登录之后的操作
     if(voting_switch!=1){
        ep.emit('prop_err', '投票系统无法重复关闭');
       
    }else{
        voting_switch=2;
        global.voting_switch=2;
        ep.emit('prop_success', '投票系统关闭成功');
        writeBackSwitch(voting_switch);  
    }

    return;
}     