let register= require('./register') ;
let candidates= require('./candidates.js') ;
let login= require('./login.js') ;
let switchs= require('./switchs.js') ;
let voting= require('./voting.js') ;;
let auth= require('../../middlewares/auth.js').auth ;

let express = require('express');
let router = express.Router();


//处理请求前进行令牌校验  除了注册之外
router.use('/',auth);




router.get('/register', register.verficationCode);//获取验证码
router.put('/register', register.signup);//注册verficationCode
router.post('/login', login.login);//工作人员登录
router.get('/candidates', candidates.getCandidates);//获取候选人信息，返回包括了投票信息
router.put('/candidates', candidates.addCandidates);//增加候选人
router.post('/candidates', candidates.modifyCandidates);//增加候选人
router.delete('/candidates', candidates.deleteCandidates);//删除候选人
router.get('/switchs', switchs.voteBegin);//开
router.post('/switchs', switchs.voteEnd);//关
router.post('/voting', voting.voteCandidates);//投票










module.exports = router;


