var validator      = require('validator');
var eventproxy     = require('eventproxy');
var config         = require('../../config');
var Candidates           = require('../../proxy').Candidates;
var User           = require('../../proxy').User;


/*
投票
*/

exports.voteCandidates=function(req,res){
  
    //接收传递过来的Json对象
    var candidate_ids     = validator.trim(req.query.candidate_ids).toLowerCase(); 
    var ids=candidate_ids.split('|');
    var user_mail=req.decoded.user.user_mail;//获取解密信息
    //var user_mail='406999666@qq.com';
    var ep = new eventproxy();
    
     ep.on('prop_err', function (msg) {
      res.status(412);   
      res.json({reMsg : msg});
    
      });
      
      ep.on('prop_success', function (msg) {
        res.status(200);           
        res.json({reMsg : msg});
    
      });
       
    //判断投票是否开始了
    if(global.voting_switch!=1){
        ep.emit('prop_err', '投票时间未开始或者已结束');
        return;
    }
    
    //判断该用户是否已经投过票
    Candidates.userVoteIf(user_mail,function(err,doc){
        if(doc){
            ep.emit('prop_err', '您已经投过票了');
            return;
        }
                
        
        Candidates.getCandidates(function(err,doc){         
           var  candidate_num=doc.length;
           var limit_up_num=(candidate_num/5)<=candidate_num?(2):(candidate_num/5);       
               //如果20%的总人数不超过2人的话，那么依然可以选择2人

            //判断投票数是否合法  大于等于2 小于等于20%总候选人数
            if( ids.length<2 || ids.length>limit_up_num ){
                ep.emit('prop_success', '投票人数不正确');
                return;
            }
            
            
        //进行投票处理

        Candidates.voteCandidates(ids,function(err,doc){
            if(!err){

                Candidates.voteCandidatesUserOp(user_mail,candidate_ids,function(err,doc){
                    //投票人进行记录
                    if(!err){
                        ep.emit('prop_success', '投票操作成功');
                        return;
                    } else{
                        ep.emit('prop_success', '投票操作成功，用户操作未记录');
                        logger.error(user_mail+"用户投票未进行记录");
                        return;
                    }                   
                })
                   
            }else{
                ep.emit('prop_err', '投票操作失败');
                return;
            }
    
        });


        });
       



       
        


    });

     
      };


