let express = require('express');
let path = require('path');
let router = express.Router();
let api = require('./api');

router.use('/api', api);

router.use('*', (req, res) => {
    res.status(404);
    res.send('404');
});
module.exports = router;

