/**
 * config
 */

var path = require('path');

var config = {
  

  name: 'DragonMount_', //发送邮件的头
  description: '', 

  // 添加到 html head 中的信息
  site_headers: [
    '<meta name="author" content="LRN@CRN" />'
  ],

  host: 'localhost',

//工作人员账号密码配置
  admin:
  {
    user_account:'admin',
    user_pass:new Buffer('MzQyODA2YWJjZA==', 'base64').toString()
  },

  // mongodb 配置
  db: 'mongodb://dilili:dilili@127.0.0.1/voting_db',


 //JWT的加密密钥配置
  jsontoken_secret:'voting_secure123*!@#',
  
  //验证码加密密钥配置
  valificationCodeSecret:'Dililidada',
  
  
  // 程序运行的端口
  port: 88,
  
  //日志目录配置
  log_dir: path.join(__dirname, 'logs'),
  
  // 邮箱配置
  mail_opts: {
    host: 'smtp.163.com',
    port: 25,
    auth: {
      user: 'she6967@163.com',
      pass: new Buffer('MzQyODA2YWJjZA==', 'base64').toString()
    },
    ignoreTLS: true,
  }
};
module.exports = config;
