var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var config = require('./config.js');
var app = express();
var isDev = false;
var router = require('./router');
var port=config.port;
global.voting=1;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));


// function resolveStaticPath(dirname) {
    // let pre = isDev ? './server' : './';
    // return path.join(pre, dirname);
// }

app.use('/', router);

console.log('port', port);
app.listen(port, function () {
    console.log('Listening on ' + port);
});