var models  = require('../models');
var Candidates    = models.Candidates;
var User    = models.User;



/**
 * 新增候选人信息
 * - err, 数据库异常
 */
exports.addCandidates = function (candidates,callback) {
    
    var data={'candidate_name':candidates.candidate_name,'candidate_id':candidates.candidate_id};
    return Candidates.create(data,callback);
   
 };
 

/**
 * 凭竞选编号获取候选人信息
 * - err, 数据库异常
 */
exports.getCandidateById = function (candidate_id,callback) {
    
    return Candidates.find( {'candidate_id':candidate_id}, callback );
       
 };
 

/**
 * 获取候选人信息
 * - err, 数据库异常
 */
exports.getCandidates = function (callback) {
 
    return Candidates.find({},'candidate_id candidate_name tickets',callback);
   
 };
 
/**
 *  修改候选人信息
 * - err, 数据库异常
 */
exports.modifyCandidates = function (candidate_id,candidate_name,callback) {
    
    candidate_name=candidate_name;

    return Candidates.findOneAndUpdate({'candidate_id':candidate_id},{'candidate_name':candidate_name},callback);
   
 };
 
/**
 *  删除候选人信息
 * - err, 数据库异常
 */
exports.deleteCandidates = function (candidate_id,callback) {
    

    return Candidates.findOneAndRemove({'candidate_id':candidate_id},callback);
   
 };
 


/**
 *  查询用户投票信息
 * - err, 数据库异常
 */
exports.userVoteIf = function (user_mail,callback) {
    
    return User.findOne({'user_mail':user_mail,'votes_info':{$ne:''},'votes_info':{$ne:null} },callback);
   
 };
 




 /**
 *  投票进行用户数据修改增加投票记录
 * - err, 数据库异常
 */
exports.voteCandidatesUserOp = function (user_mail,candidate_ids,callback) {

    return User.findOneAndUpdate(
        {'user_mail':user_mail},
        {'votes_info':candidate_ids},
        callback);
   
 };
 




 /**
 *  投票
 * - err, 数据库异常
 */
exports.voteCandidates = function (ids,callback) 
{

    //更新 是的所有被投票的人 票数增1
    return Candidates.updateMany({'candidate_id':{$in:ids}},{$inc:{'tickets':1}},callback);
   
 };
 
 